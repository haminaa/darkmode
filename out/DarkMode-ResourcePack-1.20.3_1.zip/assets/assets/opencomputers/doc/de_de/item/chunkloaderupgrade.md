# Chunkloader-Upgrade

![Geht nirgendwo hin.](oredict:oc:chunkloaderUpgrade)

Das Chunkloader-Upgrade kann in Geräten wie [Robotern](../block/robot.md) oder [Mikrocontrollern](../block/microcontroller.md) installiert werden, um den Chunk in dem er sich befindet sowie umliegende Chunks geladen zu halten. Dies verbraucht jedoch Energie. Der Chunkloader kann mit der Komponenten-API ein- oder ausgeschaltet werden.

Das Upgrade ist automatisch aktiviert wenn das Gerät aktiviert, und automatisch deaktiviert, wenn das Gerät deaktiviert wird.
