# Linked Card

![I feel we some kind of connection.](oredict:oc:linkedCard)

The linked card is a specialized but advanced version of a [network card](lanCard.md). It can only operate in pairs, providing a point-to-point communication between the paired cards. Linked cards can communicate over large (unlimited) distances and across dimensions. 