# Inventory Upgrade

![Where does it keep all this stuff...](oredict:oc:inventoryUpgrade)

The inventory upgrade provides inventory slots to [robots](../block/robot.md) and [drones](drone.md). For each inventory upgrade a [robot](../block/robot.md) will gain an addition 16 inventory slots, up to a maximum of 64 slots in total; a [drone](drone.md) will gain 4 slots per upgrade, up to a total of 8 slots.

If no inventory upgrade is installed in a device it will not be able to store or pick up items.
