# Traktorstrahl-Upgrade

![Beam me up.](oredict:oc:tractorBeamUpgrade)

Das Traktorstrahl-Upgrade erlaubt es Geräten Items in einem Drei-Block-Radius um sie herum aufzusammeln. Dies kann besonders nützlich sein, wenn [Roboter](../block/robot.md) in Baum- oder anderen Farmen eingesetzt werden, oder wenn sie verschiedene Werkzeuge um Abbau von unterschiedlichen Blöcken einsetzen. Jeder Einsatz saugt einen einzelnen Itemstack auf und verbraucht Energie.
