# Microchips

![Nicht essbar.](oredict:oc:circuitChip1)

Microchips sind die Grundlage für das Bauen von elektronischen Komponenten. Sie kommen in verschiedenen Stufen und ermöglichen unterschiedliche Komponentenstufen.
