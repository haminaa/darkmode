# Festplatte

![01010011 01110000 01100001 01100011 01100101.](oredict:oc:hdd1)

Die Festplatten haben mehr Speicherplatz als andere OpenComputers-Speichermedien. Alle Medien arbeiten gleich schnell, haben allerdings unterschiedliche Speicherplatzgrößen. Es gibt auch Geräte die nur Disketten verwenden. Festplatten können in einem [RAID](../block/raid.md) platziert werden, um Geräten das Teilen des selben Dateisystems zu ermöglichen. Wenn eine Festplatte in einem RAID platziert werden, werden allerdings die Daten gelöscht.
