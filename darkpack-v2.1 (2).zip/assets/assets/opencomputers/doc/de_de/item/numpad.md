# Ziffernblock

![Prüfe es auf Fingerabdrücke.](oredict:oc:materialNumPad)

Der Ziffernblock ist Teil einer jeden [Tastatur](../block/keyboard.md). Es erlaubt es, Zahlen einzugeben.
